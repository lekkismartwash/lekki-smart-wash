Lekki Smart Wash - Website

This is a simple React + Vite single-page site built for Lekki Smart Wash.

How to run locally:
1. npm install
2. npm run dev

The site includes:
- Header with logo (src/assets/logo.png)
- Light blue theme
- 'Request for Pick Up Now' WhatsApp button
- Footer with contact info and interactive Google Map
