import React from "react";

export default function App() {
  const whatsapp = "https://wa.me/+2347077673997";
  const instagram = "https://instagram.com/lekkismartwash";
  return (
    <div className="min-h-screen font-sans text-slate-800 bg-white">
      <header style={{backgroundColor:"#e6f3ff"}} className="py-4 shadow-sm">
        <div className="max-w-6xl mx-auto px-6 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <img src="/src/assets/logo.png" alt="Lekki Smart Wash" style={{width:64, height:64, objectFit:"contain", borderRadius:12}} />
            <div>
              <h1 style={{margin:0, fontSize:20, fontWeight:700}}>Lekki Smart Wash</h1>
              <p style={{margin:0, color:"#334155"}} className="text-sm">We Wash. You Relax.</p>
            </div>
          </div>
          <nav className="hidden md:flex items-center gap-6 text-sm">
            <a href="#services" className="hover:underline">Services</a>
            <a href="#about" className="hover:underline">About</a>
            <a href="#contact" className="hover:underline">Contact</a>
            <a href={whatsapp} className="inline-block px-4 py-2 rounded-lg font-semibold" style={{backgroundColor:"#cfeefe", color:"#0ea5e9"}}>Request for Pick Up Now</a>
          </nav>
          <div className="md:hidden">
            <a href={whatsapp} className="inline-block px-3 py-2 rounded-lg font-semibold" style={{backgroundColor:"#cfeefe", color:"#0ea5e9"}}>Pickup</a>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-6 py-10">
        <section className="grid md:grid-cols-2 gap-8 items-center">
          <div>
            <h2 style={{fontSize:36, margin:0, fontWeight:800}}>We Wash. You Relax.</h2>
            <p style={{color:"#475569", marginTop:12}}>Friendly & Convenient (Everyday Lifestyle) — Pickup, expert cleaning, and delivery for busy Lagos life.</p>
            <div style={{marginTop:18}}>
              <a href={whatsapp} className="inline-block px-5 py-3 rounded-lg font-semibold" style={{backgroundColor:"#0ea5e9", color:"white"}}>Request for Pick Up Now</a>
            </div>

            <div className="mt-8 grid grid-cols-2 gap-4 text-sm" style={{color:"#475569"}}>
              <div>
                <div style={{fontWeight:700}}>Free pickup</div>
                <div className="text-xs">On orders above ₦5,000</div>
              </div>
              <div>
                <div style={{fontWeight:700}}>Fast turnaround</div>
                <div className="text-xs">Same-day & next-day options</div>
              </div>
            </div>
          </div>

          <div>
            <div style={{background:"#ffffff", padding:16, borderRadius:18, boxShadow:"0 6px 18px rgba(15,23,42,0.06)"}}>
              <img src="/src/assets/uploaded_3.png" alt="laundry" style={{width:"100%", borderRadius:12, height:220, objectFit:"cover"}}/>
              <div style={{marginTop:12}}>
                <h3 style={{margin:0, fontWeight:700}}>Doorstep laundry made simple</h3>
                <p style={{marginTop:6, color:"#475569"}}>Book through WhatsApp — we collect, clean and return with care.</p>
              </div>
            </div>
          </div>
        </section>

        <section id="services" className="mt-12">
          <h3 style={{fontSize:22, fontWeight:700}}>Our Services</h3>
          <p style={{color:"#475569"}}>Everything from everyday washes to special-care garments.</p>
          <div className="mt-6 grid md:grid-cols-3 gap-6">
            <ServiceCard title="Wash, Dry & Fold" desc="Perfect for everyday clothing — fast, fresh and folded." badge="Popular" />
            <ServiceCard title="Dry Cleaning & Delicates" desc="Suits, dresses, and delicate fabrics handled with expert care." />
            <ServiceCard title="Pickup & Delivery" desc="Doorstep collection and return. Schedule at your convenience." />
          </div>
        </section>

        <section id="about" className="mt-12 bg-white p-6 rounded-xl shadow-sm">
          <h3 style={{fontSize:22, fontWeight:700}}>About Lekki Smart Wash</h3>
          <p style={{color:"#475569"}}>At Lekki Smart Wash we make laundry effortless. Using modern equipment and eco-friendly detergents, we handle each garment with care — so you can spend time on what matters.</p>
        </section>
      </main>

      <footer id="contact" style={{backgroundColor:"#e6f3ff"}} className="mt-12 py-10">
        <div className="max-w-6xl mx-auto px-6 grid md:grid-cols-2 gap-8">
          <div>
            <h4 style={{fontSize:20, fontWeight:700, margin:0}}>Get in touch</h4>
            <p style={{color:"#475569", marginTop:8}}>Request pickup, ask a question, or follow us on social media.</p>
            <div style={{marginTop:12}} className="flex flex-col sm:flex-row gap-3">
              <a href={whatsapp} className="inline-block px-4 py-3 rounded-lg font-semibold" style={{backgroundColor:"#0ea5e9", color:"white"}}>Request for Pick Up Now</a>
              <a href="https://wa.me/+2347077673997" className="inline-block px-4 py-3 rounded-lg font-semibold" style={{backgroundColor:"#cfeefe", color:"#0ea5e9"}}>WhatsApp</a>
              <a href="https://instagram.com/lekkismartwash" className="inline-block px-4 py-3 rounded-lg font-semibold" style={{backgroundColor:"#cfeefe", color:"#0ea5e9"}}>Instagram</a>
            </div>

            <div style={{marginTop:12, color:"#475569"}}>
              <div><strong>Email:</strong> info@lekkismartwash.com</div>
              <div style={{marginTop:6}}><strong>Address:</strong> Lekki Phase 1, Lagos, Nigeria</div>
            </div>
          </div>

          <div>
            <div style={{height:320, borderRadius:12, overflow:"hidden"}}>
              <iframe title="Lekki Phase 1 Map" src="https://www.google.com/maps?q=Lekki%20Phase%201%2C%20Lagos%2C%20Nigeria&output=embed" width="100%" height="100%" style={{border:0}} allowFullScreen loading="lazy"></iframe>
            </div>
          </div>
        </div>

        <div className="max-w-6xl mx-auto px-6 mt-8 text-sm" style={{color:"#475569"}}>
          © 2025 Lekki Smart Wash. All rights reserved.
        </div>
      </footer>
    </div>
  );
}

function ServiceCard({ title, desc, badge }) {
  return (
    <div style={{background:"#ffffff", padding:20, borderRadius:12, boxShadow:"0 6px 18px rgba(15,23,42,0.04)"}}>
      <div style={{display:"flex", justifyContent:"space-between"}}>
        <div>
          <h4 style={{margin:0, fontWeight:700}}>{title}</h4>
          <p style={{color:"#475569", marginTop:8}}>{desc}</p>
        </div>
        {badge && <div style={{fontSize:12, background:"#cfeefe", color:"#0ea5e9", padding:"6px 8px", borderRadius:6, height:30, alignSelf:"start"}}>{badge}</div>}
      </div>
    </div>
  );
}
